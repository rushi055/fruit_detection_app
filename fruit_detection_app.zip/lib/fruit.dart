class Fruit {
  String name;
  int calories;

  Fruit(this.name, this.calories);
}
